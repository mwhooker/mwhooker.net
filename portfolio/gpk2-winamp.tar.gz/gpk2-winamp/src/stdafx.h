#pragma once

// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#define _WIN32_WINNT 0x502
#include <windows.h>
#include <string>
using namespace std;
#include <loki/Singleton.h>
