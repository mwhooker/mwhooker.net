void DebugSpew(const wchar_t *szFormat, ...);
void DebugSpewAlways(const wchar_t *szFormat, ...);



