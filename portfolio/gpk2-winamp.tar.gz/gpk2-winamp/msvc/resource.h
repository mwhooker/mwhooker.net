//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dialog.rc
//

#define IDD_UNP                         102
#define IDC_EDIT_USERNAME               1002
#define IDC_EDIT_PASSWORD               1003
#define IDC_OK                          1004
#define ID_UNAME_TEXT                   1005
#define ID_PASSWORD_TEXT                1006
#define IDC_PROMPT                      1007
#define IDC_CANCEL                      1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
