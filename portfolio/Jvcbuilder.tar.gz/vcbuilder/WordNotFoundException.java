package vcbuilder;

public class WordNotFoundException extends Exception {

	public WordNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
