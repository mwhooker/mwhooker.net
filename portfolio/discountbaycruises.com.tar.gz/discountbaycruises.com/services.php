<?php
	include_once "login/functions.php";
    php?>
<html>

<head>
<meta http-equiv="CoFntent-Type" content="text/html; charset=windows-1252">
<title>DiscountBayCruises.com - Our Services</title>
<style>

.bot{
	color: FFCC00;
	font-size: 11px;
	font-family: tahoma,verdana,arial;
}
.bot:hover{color: red;}

TD{
font-size: 11px;
FONT-FAMILY: tahoma,verdana,arial;
color: BDBDBD;
}
</style>
<script language="JavaScript1.2" src="mm_functions.js"></script>
</head>

<body LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH="0" MARGINHEIGHT="0" onLoad="MM_preloadImages('images/but1.gif','images/but2.gif','images/but3.gif','images/but4.gif','images/but5.gif','images/but6.gif','images/but1_2.gif','images/but2_2.gif','images/but3_2.gif','images/but4_2.gif')">

<script language="JavaScript1.2">mmLoadMenus();</script>

<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" bgcolor="#FFFFFF" style="border-collapse: collapse" bordercolor="#111111">
  <tr>
    <td colspan="3" width="830" background="images/fon3.gif">
    <img border="0" src="images/master-MP_01.gif" width="611" height="24"><img border="0" src="images/master-MP_02.gif" width="165" height="24"><br>
			<IMG SRC="images/master-MP_05.gif" ALT="" width="55" height="24"><a href="index.php"><img border="0" src="images/services_06.gif" width="45" height="24"></a><a href="links.htm"><img border="0" src="images/services_07.gif" width="47" height="24"></a><a href="https://pro12.abac.com/sfdbc/purchase.php"><img border="0" src="images/services_08.gif" width="118" height="24"></a><a href="vtour.htm"><img border="0" src="images/services_09.gif" width="84" height="24"></a><a href="mailto:webmaster@discountbaycruises.com"><img border="0" src="images/services_10.gif" width="74" height="24"></a><img border="0" src="images/services_11.gif" width="188" height="24"><img border="0" src="images/t5.gif" width="17" height="24"><a onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image13','','images/but1_2.gif',1)" href="index.php"><img src="images/but1.gif" name="Image13" border="0" width="21" height="24"></a><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_showMenu(window.mm_menu_0201175758_0,650,45,null,'links');MM_swapImage('Image14','','images/but2.gif',1)"><img src="images/but2_2.gif" name="Image14" border="0" width="21" height="24"></a><a onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image15','','images/but3_2.gif',1)" href="https://pro12.abac.com/sfdbc/purchase.php"><img src="images/but3.gif" name="Image15" border="0" width="19" height="24"></a><a onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image16','','images/but4_2.gif',1)" href="mailto:webmaster@discountbaycruises.com"><img src="images/but4.gif" name="Image16" border="0" width="21" height="24"></a><img border="0" src="images/services_17.gif" width="66" height="24"><br>
    <img border="0" src="images/services_18.gif" width="776" height="139"><br>
    <img border="0" src="images/services_20.gif" width="287" height="39"><img border="0" src="images/services_21.jpg" width="212" height="39"><img border="0" src="images/services_22.jpg" width="100" height="39"><img border="0" src="images/services_23.gif" width="177" height="39"><table border="0" width="786" height="216" cellspacing="0" cellpadding="0" background="images/servicesbgpsd.jpg">
        <tr>
          <td valign="top" style="padding-left: 50; padding-right: 16" width="340" height="216">
          <p align="justify"><font face="Tahoma">The Discount Bay Cruises
          Service combines the simplicity and efficiency of an automated
          internet-based retailer with the personalized service and care of a
          well-run ticket office. We pay close attention to our clients'
          feedback to ensure that your ticket-buying experience is a smooth and
          enjoyable one.&nbsp; Please direct your questions and comments to
          <a class="bot" href="mailto:questions@discountbaycruises.com">
          questions@discountbaycruises.com</a>.</font></p>
          <p align="justify">	<font face="Tahoma">To order a ticket, click the
          &quot;Purchase&quot; button to the right and follow the instructions. You
          will then be presented with a voucher which can be redeemed only at
          pier 43</font><sup><font face="Tahoma">1/2</font></sup><font face="Tahoma">.
          Maps and directions are provided by MapQuest and can be
          found </font> <a class="bot" href="http://www.mapquest.com/maps/map.adp?searchtype=address&formtype=search&countryid=US&addtohistory=&country=US&address=Jefferson+St+%26+Taylor+St&city=San+Francisco&state=CA&zipcode=94133&historyid=&submit=Get+Map">
          <font face="Tahoma">here</font></a><font face="Tahoma">. We thank you
          for your interest and hope you enjoy the sights and sounds of San
          Francisco Bay.</font><br>
          &nbsp;</td>
          <td valign="top" width="122" height="216">
          	<img border="0" src="images/services_26.jpg" width="122" height="217"></td>
          <td valign="top" style="padding-left: 13; padding-right: 44" width="232" height="216">
          <p align="justify">
          <img border="0" src="images/services_28.gif" width="220" height="30"><br>
          The voucher is a quick way to bypass the line at the ticket booth.
          Simply print your voucher and keep it until the day of your cruise,
          and then present it at pier <font face="Tahoma">43</font><sup><font face="Tahoma">1/2</font></sup>,
          San Francisco. Your voucher will be valid for any departure time on
          any day up to three months after the date of its purchase. For questions please email
          <a class="bot" href="mailto:questions@discountbaycruises.com">questions@discountbaycruises.com</a><br>
          <a href="https://pro12.abac.com/sfdbc/purchase.php">
          <img border="0" src="images/services_32.gif" width="115" height="43"></a></td>
        </tr>
      </table></td>
    <td width="162" background="images/fon3.gif"></td>
  </tr>
  <tr>
    <td background="images/fon1.gif" valign="top" width="463">
    <img border="0" src="images/winter_spring_sched.gif" width="399" height="39"><div style="padding-left: 50px; padding-right: 20px; width: 358px; height: 204px;">
      <a name="schedule">Below are the fall departure times.</a><br>
      <table style="border-collapse: collapse;" bordercolordark="#144E56" bordercolorlight="#144E56" bgcolor="#103f46" border="1" bordercolor="#144e56" cellpadding="6" cellspacing="0" height="64%" width="329">
          <tbody><tr>
            <td align="justify" height="20%" valign="top" width="33%">
            10:00 AM</td>
            <td align="justify" height="20%" valign="top" width="33%">
            1:15 PM</td>
            <td align="justify" height="20%" valign="top" width="33%">
            3:45 PM<br></td>
          </tr>
          <tr>
            <td align="justify" height="20%" valign="top" width="33%">
            10:45 PM*</td>
            <td align="justify" height="20%" valign="top" width="33%">
            1:45 PM</td>
            <td align="justify" height="20%" valign="top" width="33%">
            4:15 PM*</td>
          </tr>
          <tr>
            <td align="justify" height="20%" valign="top" width="33%">
            11:15 PM</td>
            <td align="justify" height="20%" valign="top" width="33%">
            2:30 PM</td>
            <td align="justify" height="20%" valign="top" width="33%">
            &nbsp;</td>
          </tr>
          <tr>
            <td align="justify" height="20%" valign="top" width="33%">
            12:00 PM</td>
            <td align="justify" height="20%" valign="top" width="33%">
            3:00 PM</td>
            <td align="justify" height="20%" valign="top" width="33%">
            &nbsp;</td>
          </tr>
        </tbody></table>
        *Weekends only between 1/3/05 and 3/25/05</div></td>
    <td valign="top" bgcolor="#0A292D" width="1">
    <img border="0" src="images/line.gif" width="1" height="39"></td>
    <td background="images/fon1.gif" valign="top" width="366">
    <img border="0" src="images/services_39.gif" width="366" height="39"><div style="padding-left: 30">
<A NAME="fares">
      Our fares are constantly getting better to remain consistently <br>cheap.
      Check back on our site frequently to see our rates.</A>
              <br><br><table border="1" width="306" bordercolor="#144E56" height="152" cellspacing="0" cellpadding="0" bgcolor="#103E45">
        <tr>
          <td bgcolor="#FFCC00" align="center"><b><font color="#000000">Services</font></b></td>
          <td bgcolor="#FFCC00" align="center"><font color="#000000"><b>Fares</b></font></td>
        </tr>
        <tr>
          <td style="padding-left: 10; padding-right: 10"><font color="#FFFFFF">
          Adult</font></td>
          <td style="padding-left: 10; padding-right: 10">
          <p align="center"><font color="#FFFFFF"><strike><font face="Tahoma">
          <?php printf ("$%d.00",retrieve_last_fare("bay", "adult","old"));?></font></strike>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <?php printf ("$%d.00",retrieve_last_fare("bay", "adult","update"));?></font></td>
        </tr>
        <tr>
          <td style="padding-left: 10; padding-right: 10"><font color="#FFFFFF">
          Senior (60+)</font></td>
          <td style="padding-left: 10; padding-right: 10">
          <p align="center"><font color="#FFFFFF"><strike><font face="Tahoma">
          <?php printf ("$%d.00",retrieve_last_fare("bay", "senior","old"));?></font></strike>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <?php printf ("$%d.00",retrieve_last_fare("bay", "senior","update"));?></font></td>
        </tr>
        <tr>
          <td style="padding-left: 10; padding-right: 10"><font color="#FFFFFF">
          Teen (12-18)</font></td>
          <td style="padding-left: 10; padding-right: 10">
          <p align="center"><font color="#FFFFFF"><strike><font face="Tahoma">
          <?php printf ("$%d.00",retrieve_last_fare("bay", "teen","old"));?></font></strike>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <?php printf ("$%d.00",retrieve_last_fare("bay", "teen","update"));?></font></td>
        </tr>
        <tr>
          <td style="padding-left: 10; padding-right: 10"><font color="#FFFFFF">
          Child (5-11)</font></td>
          <td style="padding-left: 10; padding-right: 10">
          <p align="center"><font color="#FFFFFF"><strike><font face="Tahoma">
          <?php printf ("$%d.00",retrieve_last_fare("bay", "child","old"));?></font></strike>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <?php printf ("$%d.00",retrieve_last_fare("bay", "child","update"));?></font></td>
        </tr>
      </table>
</div></td>
    <td width="162" background="images/fon1.gif"></td>
  </tr>
  <tr>
    <td background="images/fon2.gif" height="100%" width="463">&nbsp;</td>
    <td background="images/fon2.gif" height="100%" width="1"></td>
    <td background="images/fon2.gif" height="100%" width="366"></td>
    <td width="162" background="images/fon2.gif"></td>
  </tr>
  <tr>
    <td style="padding-left: 0" bgcolor="#103E45" height="37" width="463"><font color="#FFFFFF">
    2004, 2005 (c) Copyright DiscountBayCruises.com. All rights reserved.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></td>
    <td style="padding-right: 0" bgcolor="#103E45" height="37" colspan="2" align="right" width="367">
    <p align="center"><font color="#FFFFFF">&nbsp;<a class="bot" href="index.php">home</a>&nbsp; |&nbsp;
    <a class="bot" href="links.htm">links</a>&nbsp;
      |&nbsp;<a class="bot" href="https://pro12.abac.com/sfdbc/purchase.php">purchase voucher</a>&nbsp; |&nbsp;
    <a class="bot" href="vtour.htm">virtual tour</a>&nbsp;
      |&nbsp; <a href="mailto:webmaster@discountbaycruises.com" class="bot">contact us</a></font></td>
    <td width="162" bgcolor="#103E45"></td>
  </tr>
</table>

</body>
</html>