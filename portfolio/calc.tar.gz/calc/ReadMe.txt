Compilation instructions:
load the project and hit compile. (F5 or ctrl+F5 under most MSVC installs)


contact:
Matthew Hooker
mwhooker@gmail.com
www.gerpok.com




From Joe, the program author:
My bosses over at megatelle.com asked me to create a fully functional calculator for some internal stuff, or something. Since it's only my first year there, I wanted to make a good impression. I got to creating a very intuitive and user-friendly UI (with which to really bust out some synergy with) and then started thinking about how to actually implement it. I know company time is important, so I didn't want to spend all year coding it from scratch. So about a week in to the project, as I was going through my notes from school (CS110B -- Programming Fundamentals: C++), I remember them saying something about code reuse. Perfect! My Windows XP User class showed us the Windows Calculator, which shurely does what I need to do already. I'll just reuse that code, I thought. 
As it turns out, reusing code that you don't have the source code to is really hard. I don't even have a discompiler or whatever! Luckily, I dreamed the solution (it was in India all along), and it only took 4 months. My boss didn't seem all that proud of me, though, because he fired me. So I'm submitting it to this contest because I really need the money.