VOID DebugSpewAlways(PCHAR szFormat, ...);
VOID DebugSpew(PCHAR szFormat, ...);
VOID DebugSpewNoFile(PCHAR szFormat, ...);
