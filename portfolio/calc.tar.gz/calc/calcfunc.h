
double DoOperation(char operation, double op1, double op2, int* isErr);

double DoAdd(double op1, double op2);
double DoSub(double op1, double op2);
double DoMul(double op1, double op2);
double DoDiv(double op1, double op2, int* isErr);